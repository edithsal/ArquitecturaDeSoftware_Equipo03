/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.modelo_mvc;



/**
 *
 * @author LENOVO
 */
public class Parchis_MVC {
   
}
